
(function () {
  "use strict";
  var root = document.documentElement;

  var theme = null;
  try { theme = localStorage.getItem("vp-theme"); } catch (e) {  }
  if (theme === "dark" ||
      (theme === null && window.matchMedia &&
       window.matchMedia("(prefers-color-scheme: dark)").matches)) {
    root.setAttribute("data-theme", "dark");
  }
  try {
    if (localStorage.getItem("vp-sidebar") === "closed") {
      root.classList.add("sidebar-collapsed");
    }
  } catch (e) {  }

  try {
    if (localStorage.getItem("vp-notices") === "closed") {
      root.classList.add("notices-collapsed");
    }
  } catch (e) {  }

  window.addEventListener("DOMContentLoaded", function () {
    var noticesBtn = document.getElementById("notices-toggle");
    if (noticesBtn) {
      noticesBtn.addEventListener("click", function () {
        var closed = root.classList.toggle("notices-collapsed");
        try { localStorage.setItem("vp-notices", closed ? "closed" : "open"); } catch (e) {  }
      });
    }
    var themeBtn = document.getElementById("theme-toggle");
    if (themeBtn) {
      themeBtn.addEventListener("click", function () {
        var dark = root.getAttribute("data-theme") === "dark";
        if (dark) { root.removeAttribute("data-theme"); }
        else { root.setAttribute("data-theme", "dark"); }
        try { localStorage.setItem("vp-theme", dark ? "light" : "dark"); } catch (e) {  }
      });
    }
    var sidebarBtn = document.getElementById("sidebar-toggle");
    if (sidebarBtn) {
      sidebarBtn.addEventListener("click", function () {
        var closed = root.classList.toggle("sidebar-collapsed");
        try { localStorage.setItem("vp-sidebar", closed ? "closed" : "open"); } catch (e) {  }
      });
    }
  });
})();
