(function () {
    "use strict";

    var box = document.querySelector("[data-qos-toggle]");
    var fields = document.querySelectorAll("[data-qos-field]");
    function syncFields() {
        if (!box) { return; }
        fields.forEach(function (f) { f.disabled = !box.checked; });
    }
    if (box) {
        box.addEventListener("change", syncFields);
        syncFields();
    }

    var running = document.querySelector("[data-speedtest-running]");
    if (running) {
        var timer = setInterval(function () {
            fetch("/qos/speedtest/status", { credentials: "same-origin" })
                .then(function (r) { return r.json(); })
                .then(function (st) {
                    if (!st.running) {
                        clearInterval(timer);
                        window.location.reload();
                    }
                })
                .catch(function () {  });
        }, 2000);
    }

    document.querySelectorAll("[data-fill-tariff]").forEach(function (btn) {
        btn.addEventListener("click", function (ev) {
            ev.preventDefault();
            var down = document.querySelector("input[name=down_mbit]");
            var up = document.querySelector("input[name=up_mbit]");
            if (down) { down.value = btn.getAttribute("data-down"); }
            if (up) { up.value = btn.getAttribute("data-up"); }
            if (box && !box.checked) { box.checked = true; syncFields(); }
            if (down) { down.scrollIntoView({ behavior: "smooth", block: "center" }); }
        });
    });
}());
